package com.mmju.jsp.ep6.model;

import com.mmju.jsp.ep6.EM_Model;

public class Md_add extends EM_Model {

	@Override
	public void doBusiness() {
		// TODO Auto-generated method stub

	}

}
